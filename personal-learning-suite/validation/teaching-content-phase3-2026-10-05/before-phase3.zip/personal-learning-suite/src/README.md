# 实际实现入口

本目录存放已经创建的 Agent 定义、Skill 开发包和 Python 实现。开发规格在套件 `specs`，设计研究在项目 `docs`；当前包未安装，真实模型和个人记录承载未绑定。

## 四个 Agent

| Agent | 文件 | 责任 |
|---|---|---|
| AG0 | [AG0-coach.md](agents/AG0-coach.md) | 入口、教学执行、真实发生事实、恢复与控制 |
| AG1 | [AG1-design-planning.md](agents/AG1-design-planning.md) | 目标、关键教学设计、投入与连续性安排 |
| AG2 | [AG2-materials.md](agents/AG2-materials.md) | 来源、内容、材料用途与纠错 |
| AG3 | [AG3-assessment.md](agents/AG3-assessment.md) | 表现证据、条件化判断、评估与复核 |

这些是角色定义，不能据文件存在推断四个独立模型已启动。

## 七个 Skill

| Skill | 实际入口 |
|---|---|
| SK00 学习总入口 | [personal-learning](skills/personal-learning/SKILL.md) |
| SK01 目标 | [learning-goals](skills/learning-goals/SKILL.md) |
| SK02 内容与材料 | [learning-materials](skills/learning-materials/SKILL.md) |
| SK03 教学 | [learning-teaching](skills/learning-teaching/SKILL.md) |
| SK04 评估 | [learning-assessment](skills/learning-assessment/SKILL.md) |
| SK05 计划与连续性 | [learning-planning](skills/learning-planning/SKILL.md) |
| SK06 策略 | [learning-strategies](skills/learning-strategies/SKILL.md) |

每个 Skill 的 `references` 是其正常依赖，和 SKILL.md 保存在一起。共享语义见[契约](../contracts/shared-contracts.md)，资源见[资源说明](../resources/README.md)。

## 运行程序

主 CLI 为 [personal_learning.py](runtime/personal_learning.py)；B5 顺序集成为 [entry_b5.py](runtime/entry_b5.py)，B6 受控串行宿主为 [network_b6.py](runtime/network_b6.py)，共享保存为 [learning_store.py](runtime/learning_store.py)。各专业服务位于同一个 `runtime` 目录。

具体调用、开发边界及历史验收见[套件 README](../README.md)，项目各类文档见[总导航](../../README.md)。
