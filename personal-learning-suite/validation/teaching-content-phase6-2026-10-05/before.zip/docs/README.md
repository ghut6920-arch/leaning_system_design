# 文档分类索引

原项目顶层的 57 份文档按用途分区，文件名保持。实际 Agent／Skill 位于[实现目录](../personal-learning-suite/src/README.md)，全部项目入口见[总导航](../README.md)。

## 总体架构与实施路线（5 份）

- [AI个人学习系统_Agent与Skill工作网络及实施路线_v0.md](architecture/AI个人学习系统_Agent与Skill工作网络及实施路线_v0.md)
- [AI个人学习系统_Skill架构设计_v0.md](architecture/AI个人学习系统_Skill架构设计_v0.md)
- [AI个人学习系统_整体学习流程与概念架构_v0.md](architecture/AI个人学习系统_整体学习流程与概念架构_v0.md)
- [AI个人学习系统_整体学习流程与概念架构_v1.md](architecture/AI个人学习系统_整体学习流程与概念架构_v1.md)
- [AI个人学习系统_设计流程与工作包.md](architecture/AI个人学习系统_设计流程与工作包.md)

## 工作包设计方案与交接（11 份）

- [AI个人学习系统_工作包10_验证计划与设计收口_设计方案_v0.md](designs/AI个人学习系统_工作包10_验证计划与设计收口_设计方案_v0.md)
- [AI个人学习系统_工作包2与3_联合设计方案_v0.md](designs/AI个人学习系统_工作包2与3_联合设计方案_v0.md)
- [AI个人学习系统_工作包2至4_交接对齐说明.md](designs/AI个人学习系统_工作包2至4_交接对齐说明.md)
- [AI个人学习系统_工作包4_设计方案_v0.md](designs/AI个人学习系统_工作包4_设计方案_v0.md)
- [AI个人学习系统_工作包5_C0共同教学框架_设计方案_v0.md](designs/AI个人学习系统_工作包5_C0共同教学框架_设计方案_v0.md)
- [AI个人学习系统_工作包5_Encoding_设计方案_v0.md](designs/AI个人学习系统_工作包5_Encoding_设计方案_v0.md)
- [AI个人学习系统_工作包5_Post-Encoding_设计方案_v0.md](designs/AI个人学习系统_工作包5_Post-Encoding_设计方案_v0.md)
- [AI个人学习系统_工作包6_策略使用规则_设计方案_v0.md](designs/AI个人学习系统_工作包6_策略使用规则_设计方案_v0.md)
- [AI个人学习系统_工作包7_长期计划与学习连续性_设计方案_v0.md](designs/AI个人学习系统_工作包7_长期计划与学习连续性_设计方案_v0.md)
- [AI个人学习系统_工作包8_多Agent协作与共享状态_设计方案_v0.md](designs/AI个人学习系统_工作包8_多Agent协作与共享状态_设计方案_v0.md)
- [AI个人学习系统_工作包9_跨学科用户体验与异常场景_设计方案_v0.md](designs/AI个人学习系统_工作包9_跨学科用户体验与异常场景_设计方案_v0.md)

## 研究报告与研究资源（6 份）

- [01_Encoding研究报告.md](research/01_Encoding研究报告.md)
- [02_Encoding微操作与提问库.md](research/02_Encoding微操作与提问库.md)
- [04_Encoding策略库.json](research/04_Encoding策略库.json)
- [Post-Encoding-Dynamics-深度增量研究.md](research/Post-Encoding-Dynamics-深度增量研究.md)
- [post-encoding证据台账与参考文献.md](research/post-encoding证据台账与参考文献.md)
- [Retrieval-Integration-快速矩阵.md](research/Retrieval-Integration-快速矩阵.md)

## 设计提示词（10 份）

- [AI个人学习系统_工作包10_验证计划与设计收口_设计提示词.md](prompts/AI个人学习系统_工作包10_验证计划与设计收口_设计提示词.md)
- [AI个人学习系统_工作包2与3_联合设计提示词.md](prompts/AI个人学习系统_工作包2与3_联合设计提示词.md)
- [AI个人学习系统_工作包4_设计提示词.md](prompts/AI个人学习系统_工作包4_设计提示词.md)
- [AI个人学习系统_工作包5_C0共同教学框架_设计提示词.md](prompts/AI个人学习系统_工作包5_C0共同教学框架_设计提示词.md)
- [AI个人学习系统_工作包5_Encoding_设计提示词.md](prompts/AI个人学习系统_工作包5_Encoding_设计提示词.md)
- [AI个人学习系统_工作包5_Post-Encoding_设计提示词.md](prompts/AI个人学习系统_工作包5_Post-Encoding_设计提示词.md)
- [AI个人学习系统_工作包7_长期计划与学习连续性_设计提示词.md](prompts/AI个人学习系统_工作包7_长期计划与学习连续性_设计提示词.md)
- [AI个人学习系统_工作包8_多Agent协作与共享状态_设计提示词.md](prompts/AI个人学习系统_工作包8_多Agent协作与共享状态_设计提示词.md)
- [AI个人学习系统_工作包9_跨学科用户体验与异常场景_设计提示词.md](prompts/AI个人学习系统_工作包9_跨学科用户体验与异常场景_设计提示词.md)
- [AI个人学习系统_架构设计提示词_GPT6Astra.md](prompts/AI个人学习系统_架构设计提示词_GPT6Astra.md)

## 顶层设计分析（8 份）

- [AI个人学习系统_工作包10_验证计划与设计收口_顶层设计分析.md](analysis/AI个人学习系统_工作包10_验证计划与设计收口_顶层设计分析.md)
- [AI个人学习系统_工作包2与3_联合顶层设计分析.md](analysis/AI个人学习系统_工作包2与3_联合顶层设计分析.md)
- [AI个人学习系统_工作包4_顶层设计分析.md](analysis/AI个人学习系统_工作包4_顶层设计分析.md)
- [AI个人学习系统_工作包5_Encoding_顶层设计分析.md](analysis/AI个人学习系统_工作包5_Encoding_顶层设计分析.md)
- [AI个人学习系统_工作包5_Post-Encoding_顶层设计分析.md](analysis/AI个人学习系统_工作包5_Post-Encoding_顶层设计分析.md)
- [AI个人学习系统_工作包7_长期计划与学习连续性_顶层设计分析.md](analysis/AI个人学习系统_工作包7_长期计划与学习连续性_顶层设计分析.md)
- [AI个人学习系统_工作包8_多Agent协作与共享状态_顶层设计分析.md](analysis/AI个人学习系统_工作包8_多Agent协作与共享状态_顶层设计分析.md)
- [AI个人学习系统_工作包9_跨学科用户体验与异常场景_顶层设计分析.md](analysis/AI个人学习系统_工作包9_跨学科用户体验与异常场景_顶层设计分析.md)

## 审阅与检查（3 份）

- [AI个人学习系统_工作包4_审阅评估.md](reviews/AI个人学习系统_工作包4_审阅评估.md)
- [AI个人学习系统_工作包5_C0共同教学框架_审阅评估.md](reviews/AI个人学习系统_工作包5_C0共同教学框架_审阅评估.md)
- [AI个人学习系统_架构v0_检查记录.md](reviews/AI个人学习系统_架构v0_检查记录.md)

## B0—B7交付与联合修复（12 份）

- [AI个人学习系统_B0规范与资源基线_v0.md](implementation/AI个人学习系统_B0规范与资源基线_v0.md)
- [AI个人学习系统_B1保存与入口骨架_v0.md](implementation/AI个人学习系统_B1保存与入口骨架_v0.md)
- [AI个人学习系统_B2a目标Skill与AG1目标职能_v0.md](implementation/AI个人学习系统_B2a目标Skill与AG1目标职能_v0.md)
- [AI个人学习系统_B2b内容与材料_v0.md](implementation/AI个人学习系统_B2b内容与材料_v0.md)
- [AI个人学习系统_B3a证据评估与AG3职能_v0.md](implementation/AI个人学习系统_B3a证据评估与AG3职能_v0.md)
- [AI个人学习系统_B3b教学共同核心_v0.md](implementation/AI个人学习系统_B3b教学共同核心_v0.md)
- [AI个人学习系统_B3c策略资源与配置_v0.md](implementation/AI个人学习系统_B3c策略资源与配置_v0.md)
- [AI个人学习系统_B3联合接口评估与修复_v0.md](implementation/AI个人学习系统_B3联合接口评估与修复_v0.md)
- [AI个人学习系统_B4教学专项与计划_v0.md](implementation/AI个人学习系统_B4教学专项与计划_v0.md)
- [AI个人学习系统_B5单入口纵向集成_v0.md](implementation/AI个人学习系统_B5单入口纵向集成_v0.md)
- [AI个人学习系统_B6工作网络与受控宿主_v0.md](implementation/AI个人学习系统_B6工作网络与受控宿主_v0.md)
- [AI个人学习系统_B7有限真实试用与验证工具_v0.md](implementation/AI个人学习系统_B7有限真实试用与验证工具_v0.md)

## 综合审计与补强记录（2 份）

- [AI个人学习系统_Skill与Agent设计综合审计及补强路线_2026-10-04.md](audits/AI个人学习系统_Skill与Agent设计综合审计及补强路线_2026-10-04.md)
- [AI个人学习系统_架构审计修复实施记录_2026-10-04.md](audits/AI个人学习系统_架构审计修复实施记录_2026-10-04.md)
