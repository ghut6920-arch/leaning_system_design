# AI 个人学习系统：B3 联合接口评估与修复 v0

日期：2026-10-03。评估范围为项目已有 B3a（评估）、B3b（C0 教学）与 B3c（策略配置）的运行接口、嵌套表示、共享保存、控制传播及文档语义。依据路线和既有共享契约开展有限联调，不更改 N00／D00—D11／R01—R06 原设计与研究来源。

三包的主要职责可以衔接：AG1 维护配置，AG0 执行和记录实际条件，AG3 或获授权 AG0 判断证据。问题集中在交界表示和阶段含义，存在只测试各包会遗漏的拒绝与误放行。统一约定集中维护于 [B3 联合接口约定](personal-learning-suite/contracts/b3-interop.md)，各专业接口引用它；共享对象字段仍只维护于 [pl-contracts/0.1.0](personal-learning-suite/contracts/shared-contracts.md)。

## 发现与修复

| 问题 | 影响 | 本次处理 |
|---|---|---|
| B3a 与 B3b 的 task_qualification 字段不同 | 教学保存的活动不能按原表示直接评估；真值检查可能误放行 | 一个规范表示：target_operations 与四项布尔 Fact。旧字段保守适配，未知不补 true，双表示冲突拒绝 |
| C0 未明确保存 timeline_completeness | 空暴露列表容易被误当无帮助，合格独立证据也无法明确声明完整性 | 初答请求可给显式布尔 Fact；缺失／unknown／空列表不能证明无帮助 |
| 时间与响应点读取不一致，追加帮助和先前练习未纳入最近接触 | 修订可能被当成初答时刻，近期帮助或练习仍被判足够延迟 | 使用带时区的共用时间解释；从选定响应之前最近相关练习／帮助计算，未知时刻保持待核；作答不当教师代做 |
| 子任务保留父帮助摘要，但评估未统一回查 | 继承帮助可能消失，或不相关帮助重置整主题 | 按 c0.inherited_event_refs 确切历史读取，操作范围分别解释，不另造样本 |
| 方法 purpose、材料 purpose 和 Judgment.intended_use 混用 | 合法材料可能误拒绝；仅 supported 状态也可能放行错误用途 | B3c 必填完整 material_context 并纳入 review 绑定；B3b 移交该上下文；B3a 可显式分别核材料用途与判断用途 |
| 活动复制配置引用，缺少当前采用／用途复验 | 候选、旧版或策略用途受限配置可能进入新执行 | 请求 method_config_refs＋strategy_context 连接 B3c reuse，记录实际配置，不回写活动造成修订循环 |
| 当前配置资格和历史配置事实未明确区分 | 新配置可能错误阻断旧证据，或被替换进既有原答 | 新执行核当前已采用配置；历史评估保留当时确切版本，仍服从删除及用途限制 |
| 授权有效性以非空值代替 active=true | unknown／false Fact 可能绕过有效性检查 | 现代授权统一 known.value.active=true；既有 B0 prose 仅保留明确 legacy 读取兼容 |
| 实际资源只核“已知列表”，未核目标允许范围 | 未经允许的资源仍可能支持独立资格 | 独立用途按目标 allowed_resources 检查，未知或越界保留事实并限定支持 |
| reviewed、compatible、ready、submission_ready、adopted、committed 表述交叠 | 调用成功被误读为专业采用、发生或学习达成 | 联合约定逐项定义阶段，专业采用示例补全范围、限制和时间 Fact |
| README／依赖状态仍称 B3a、B3c 未实现或未连接 | 当前能力与历史阶段混淆 | 更新现有切片及显式接口连接状态，保留 B5 自动路由、计划和宿主能力待实现边界 |

程序检查专业声明、确切引用及显式条件，不自动判断任意学科答案、验证研究效果或识别未标注的所有泄露。方法配置写“无代做”不覆盖实际帮助；配置复用通过也不证明执行完全遵守配置。已经发生的偏离须保存为事实，再由评估限定用途。

## 输入兼容与记录边界

B3c 当前 context 输入适配为 `pl-strategies-input/0.2.0`，完整 material_context 必填且参与 review_status.binding。旧配置缺此绑定时需要 AG1 重核才能用于当前复用；历史配置、演示空间和原答保持原修订，不自动迁移、重新采用或重填删除记录。通用策略资源仍为 `pl-strategies/0.1.0`，本次接口修复不改研究正文或发布指纹。

B3a 保留不传 material_context 的旧 API，同用途核验仍严格；新的 B3b 移交明确材料上下文。task_qualification 的旧 B3a／B3b 读适配只解释已有声明，不猜造实际无帮助、有效授权或合格时间。旧演示空间的非布尔资格或缺完整性可能使当前检查受限，需要专业重核；原批成功回执不替代新接口核验。

全部写入继续经同一个 LearningStore 和 records.sqlite3。配置、事件与判断分别保存，沿原 CAS、幂等、共享预算、授权、删除／暂停／用途门检查。同题初答及修订保留一个 PerformanceEvent 和一个独立样本；三包调用或多卡组合不会增加独立成功数。程序不能清除请求文件、stdout、宿主历史或外部副本。

## 验证记录

联合检查入口为 [check_b3_interop.py](personal-learning-suite/scripts/check_b3_interop.py)，行为用例为 [test_b3_interop.py](personal-learning-suite/tests/test_b3_interop.py)，报告为 [b3-interop-report.json](personal-learning-suite/validation/b3-interop-report.json)。正向情境使用明确无父帮助继承的人工活动；另设父帮助影响的负向情境，不能为使正向通过清空真实已知历史。

联合行为检查 292 项通过，0 失败／0 错误／0 跳过：跨包 11、B3a 82、B3b 47、B3c 47、B1 33、B2a 42、B2b 30。包括配置采用到 C0 事实到判断提交、父帮助限制、同事件不同响应点、未知条件、失效授权及精确历史依赖。独立复核额外发现先前练习遗漏，修复后新增相应时间用例并重新通过。

[B0 复验](personal-learning-suite/validation/b3-interop-b0-report.json)通过 32 项静态检查及 19 份来源指纹；资源构建器 --check 确认 11 份资源一致，通用来源未改。原批次报告与演示历史保留，本次报告单独记录修复后的软件行为。有限测试通过不替代完整 B10、真实 V1—V4 或学习效果验证。

## 当前贯通范围

显式顺序调用为：按当前用途检查并采用配置 → C0 复验配置和材料 → 保存实际原答／帮助／修订 → 选定响应点及材料上下文移交 → 评估检查／受控提交。可靠活动无选法需要时保留直接执行路径。

B5 的 SK00 自动路由、专业接责回执及计划实质处置仍未实现；B4 Encoding／Post 专项执行、SK05 计划、七 Skill 安装、四真实角色、唯一展示执行者和旧输出拦截仍待后续。当前贯通仅限明确虚构输入和串行受控接口，不宣称真实教学宿主已上线。
